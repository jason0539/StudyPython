from distutils.core import setup

setup(
    name = 'nester',
    version = '1.0.0',
    py_modules = ['nester'],
    author = 'jason0539',
    author_email = 'jason0539@163.com',
    url = 'http://blog.csdn.net/jason0539',
    description = 'A simple',
)